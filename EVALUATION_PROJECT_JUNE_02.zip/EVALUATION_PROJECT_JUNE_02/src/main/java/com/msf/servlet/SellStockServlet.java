package com.msf.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import com.msf.methods.DatabaseMethods;
import com.msf.methods.DbClass;

/**
 * Servlet implementation class SellStockServlet
 */

public class SellStockServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		Logger log = LogManager.getLogger();
		Connection connection = null;
		connection = DbClass.connect();
		DatabaseMethods databaseMethods = new DatabaseMethods();
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		StringBuffer jb = new StringBuffer();
		String line = null;
		BufferedReader reader = request.getReader();
		while ((line = reader.readLine()) != null) {
			jb.append(line);
		}
		JSONObject jsobj = new JSONObject(jb.toString());
		String symbol = jsobj.getString("symbol");
		int askPrice = jsobj.getInt("askPrice");
		int quantity = jsobj.getInt("quantity");

		if (quantity <= 0) {
			jsonObject.put("error", "Quantity must be greater than zero");
			jsonArray.put(jsonObject);
			out.print(jsonArray);
			return;
		}

		try {
			int bidPrice = databaseMethods.getBidPrice(connection, symbol);
			int buyPrice = databaseMethods.getBuyPrice(connection, symbol);
			if (bidPrice > 0 && askPrice < bidPrice && askPrice > buyPrice) {
				int availableQuantity = databaseMethods.getAvailableQuantity(connection, symbol);
				if (availableQuantity > 0) {
					int soldQuantity = Math.min(quantity, availableQuantity);
					int profit = databaseMethods.calculateProfit(bidPrice, askPrice, soldQuantity);
					databaseMethods.updatePortfolioTable(connection, symbol, soldQuantity, profit);
					jsonObject.put("message", "Stocks sold successfully");
					jsonObject.put("soldQuantity", soldQuantity);
					jsonObject.put("totalProfit", profit);
					jsonArray.put(jsonObject);
					out.print(jsonArray);
				} else {
					jsonObject.put("error", "No stocks available for selling");
					jsonArray.put(jsonObject);
					out.print(jsonArray);
				}
			} else if (bidPrice == 0) {
				jsonObject.put("error", "Symbol does not exist in the table");
				jsonArray.put(jsonObject);
				out.print(jsonArray);

			}

			else {
				jsonObject.put("error", "Selling is not possible for the given price");
				jsonArray.put(jsonObject);
				out.print(jsonArray);
			}
		} catch (Exception e) {
			jsonObject.put("error", "Error occurred while processing the request");
			jsonArray.put(jsonObject);
			out.print(jsonArray);
			log.fatal(e);
		} finally {
			jsonArray = new JSONArray();
			jsonObject = new JSONObject();
			DbClass.close(connection);
		}

	}
}
