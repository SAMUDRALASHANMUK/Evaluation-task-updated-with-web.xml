package com.msf.methods;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

public class DbClass {
	static Logger log = LogManager.getLogger();

	/**
	 * Retrieves the connection object and creates the connection
	 *
	 * 
	 * @return the connection object
	 * @throws Exception if an error occurs
	 */
	public static Connection connect() {
		Connection conn = null;
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:comp/env");
			DataSource dataSource = (DataSource) envContext.lookup("jdbc/Stocks");
			BasicDataSource basicDataSource = (BasicDataSource) dataSource;
			String encryptedPassword = "pgG7y7/QUlNiDhlrssJOWdgF/B/zORFS2NCFzJbcdlk=";
			String decryptedPassword = PasswordEncryptionUtil.decrypt(encryptedPassword);
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(basicDataSource.getUrl(), basicDataSource.getUsername(),
					decryptedPassword);
			basicDataSource.close();
		} catch (Exception e) {

			log.fatal("Exception in dbclass.java" + e);
		}
		return conn;
	}

	/**
	 * closes the connection
	 *
	 * 
	 * @param conn the connection object
	 * @throws Exception if an error occurs
	 */
	public static void close(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
				log.fatal("Exception in com.methods.DbClass.close(): " + e.getMessage());
			}
		}
	}
}
